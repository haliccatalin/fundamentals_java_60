package com.sda.dataTypes;

public class Vanzator {
    String orez;

    Vanzator() {
        System.out.println("Constructor vanzator");
    }

    String getOrez() {
        return orez;
    }
}
