package com.sda;

public class Main {

//     proprietati
//    volumn, material, culoare

//     metode (actiuni sau functii)
    public static void main(String[] args) {
        System.out.println("Bun venit!");
    }
}
